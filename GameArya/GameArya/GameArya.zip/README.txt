Arya - Jogo desenvolvido por André Lucas
Controles:
  - Andar: A e D
  - Pular: W ou Espaço
  - Atacar: Z e X

Instruções:
  - Extraia o conteúdo do arquivo ZIP para uma pasta
  - Execute o arquivo GameArya.exe para jogar
  - Se o antivírus alertar, adicione uma exceção para o jogo

Obrigado por jogar!